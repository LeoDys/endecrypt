package date;

import utils.Utils;

import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DateTest {

    public static void main(String[] args) {
        //测试Date
//        testDate();
        //测试Calendar
//        testCalendar();
        //测试LocalDate
//        testLocalDate();
        //测试LocalTime
//        testLocalTime();
        //测试LocalDateTime
//        testLocalDateTime();
        //测试Instant
//            testInstant();
        //测试Duration和Period
        testDurationAndPeriod();
    }

    private static void testDurationAndPeriod(){
        //Duration管理天，小时，分钟，秒，纳秒
        LocalDateTime nowLocalDateTime = LocalDateTime.now();
        LocalDateTime burnLocalDateTime = LocalDateTime.of(1986,8,9,8,8,8,888888888);
        Duration duration1 = Duration.between(burnLocalDateTime,nowLocalDateTime);
        System.out.println(duration1);
        System.out.println(duration1.getNano());;
        System.out.println(duration1.getSeconds());
        Duration duration2 = Duration.ofSeconds(duration1.getSeconds(),duration1.getNano());
        System.out.println(duration2.toHours());
        System.out.println(duration2.toHoursPart());
        //Period管理天,月,年
        Period period = burnLocalDateTime.toLocalDate().until(nowLocalDateTime.toLocalDate());
        System.out.println("间隔月数："+period.toTotalMonths());

        System.out.println(LocalDateTime.now().atOffset(OffsetDateTime.now().getOffset()).toInstant().getEpochSecond());
    }

    private static void testInstant(){
        Instant instant = Instant.now();
        System.out.println(instant);
        System.out.println(instant.getNano());             //纳秒数
        System.out.println(instant.getEpochSecond());    //1970年到现在的秒数
        System.out.println(instant.toEpochMilli());     //1970年到现在的毫秒数(和new Date().getTime() System.currentTimeMillis 一样)

        LocalDateTime localDateTime = LocalDateTime.ofInstant(new Date().toInstant(),ZoneId.systemDefault());
        System.out.println(localDateTime);
        System.out.println(localDateTime.atZone(ZoneId.systemDefault()).toInstant().getEpochSecond());
        System.out.println(localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());

    }

    private static void testLocalTime(){
        LocalTime localTime = LocalTime.now();                //获取当前时间

        LocalTime localTime2 = LocalTime.of(18, 18,18,888888888);
        System.out.println(localTime2);

        //============ LoacalDate 获取当前时间属性  ============
        System.out.println(localTime);
        System.out.println(localTime.getHour());
        System.out.println(localTime.getMinute());
        System.out.println(localTime.getSecond());

        System.out.println(localTime.plusHours(1));        //将当前时间加1时
        System.out.println(localTime.plusMinutes(1));    //将当前时间加1分钟
        System.out.println(localTime.plusSeconds(1));    //将当前时间加1秒

        System.out.println(localTime.minusHours(1));    //将当前时间减1小时
        System.out.println(localTime.minusMinutes(1));    //将当前时间减1分钟
        System.out.println(localTime.minusSeconds(1));    //将当前时间减1秒

    }

    private static void testLocalDate() {
        LocalDate localDate = LocalDate.now();                //获取当前时间：2020-06-04
        LocalDate localDate2 = LocalDate.of(2020, 6, 4);    //根据参数设置日期，参数分别为年，月，日

        System.out.println("localDate -----"+localDate);
        System.out.println("localDate2 -----"+localDate2);

        //============ LoacalDate 获取当前时间属性  ============
        System.out.println(localDate.getYear());               //获取当前年份:2019
        System.out.println(localDate.getMonth());              //获取当前月份，英文：DECEMBER
        System.out.println(localDate.getMonthValue());         //获取当前月份，数字：12

        System.out.println(localDate.getDayOfMonth());         //获取当前日期是所在月的第几天7
        System.out.println(localDate.getDayOfWeek());          //获取当前日期是星期几（星期的英文全称）:SATURDAY
        System.out.println(localDate.getDayOfYear());          //获取当前日期是所在年的第几天:341

        System.out.println(localDate.lengthOfYear());          //获取当前日期所在年有多少天
        System.out.println(localDate.lengthOfMonth());         //获取当前日期所在月份有多少天
        System.out.println(localDate.isLeapYear());            //获取当前年份是否是闰年

        //============ LoacalDate 当前时间的加减  ============
        System.out.println(localDate.minusYears(1));           //将当前日期减1年
        System.out.println(localDate.minusMonths(1));          //将当前日期减1月
        System.out.println(localDate.minusDays(1));            //将当前日期减1天

        System.out.println(localDate.plusYears(1));            //将当前日期加1年
        System.out.println(localDate.plusMonths(1));           //将当前日期加1月
        System.out.println(localDate.plusDays(1));             //将当前日期加1天

        //============ LoacalDate 当前时间的判断 ============
        System.out.println(localDate.isAfter(localDate2));                    //localDate在localDate2日期之后
        System.out.println(localDate.isBefore(localDate2));                   //localDate在localDate2日期之前
        System.out.println(localDate.isEqual(localDate2));                    //localDate和localDate2日期是否相等

        System.out.println(localDate.with(TemporalAdjusters.firstDayOfMonth()));            //本月的第1天
        System.out.println(localDate.with(TemporalAdjusters.firstDayOfNextMonth()));        //下月的第1天
        System.out.println(localDate.with(TemporalAdjusters.firstDayOfNextYear()));         //下年的第1天

        //============ LocalDate 指定时间的操作  ===============　　　　
        System.out.println(localDate.withDayOfMonth(18));                                    //本月的第几天
        System.out.println(localDate.with(TemporalAdjusters.lastDayOfMonth()));             //本月的最后一天
        System.out.println(localDate.with(TemporalAdjusters.previous(DayOfWeek.SUNDAY)));   //上一周星期天是几号
        System.out.println(localDate.with(TemporalAdjusters.next(DayOfWeek.MONDAY)));       //下一周星期一是几号
    }

    public static void testLocalDateTime(){
        System.out.println(LocalDateTime.of(2020, 5, 26, 20, 12, 30, 300));
        LocalDateTime localDateTimeWith = LocalDateTime.now();
        localDateTimeWith = localDateTimeWith.withYear(1986).withMonth(8).withDayOfMonth(9).withHour(8).withMinute(8).withSecond(8).withNano(999999999);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss.SSSSSSSSS");
        System.out.println(dateTimeFormatter.format(localDateTimeWith));

        System.out.println(LocalDateTime.parse("2020-05-26T20:09:18.223"));
        DateTimeFormatter dateTimeFormatter2 = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss.SSS");
        System.out.println(LocalDateTime.parse("1986/08/09 06:06:06.666",dateTimeFormatter2));
    }

    private static void testCalendar() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;//月份需要加1
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int week = calendar.get(Calendar.DAY_OF_WEEK);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        int millisecond = calendar.get(Calendar.MILLISECOND);
        System.out.println(calendar.getTime());
        System.out.println(calendar.getTimeInMillis());
        System.out.println(year + "-" + month + "-" + day + " " + week + " " + hour + ":" + minute + ":" + second + "." + millisecond);
        calendar.clear();// 清除所有
        calendar.set(Calendar.YEAR, 1986);
        calendar.set(Calendar.MONTH, 7);//注意7表示8月
        calendar.set(Calendar.DATE, 9);
        calendar.set(Calendar.HOUR_OF_DAY, 6);
        calendar.set(Calendar.MINUTE, 6);
        calendar.set(Calendar.SECOND, 6);
        System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime()));
    }

    private static void testDate() {
        Date date = new Date();
        System.out.println("当前年：" + date.getYear() + 1900 + "年"); // 必须加上1900
        System.out.println("当前月：" + date.getMonth() + 1 + "月"); // 0~11，必须加上1
        System.out.println("当前日：" + date.getDate() + "日"); // 1~31，不能加1
        System.out.println("字符串:" + date.toString());// 转换为String:
        System.out.println("GMT时区：" + date.toGMTString()); // 转换为GMT时区:
        System.out.println("本地时区：" + date.toLocaleString());// 转换为本地时区:
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//格式化
        System.out.println("格式化后：" + simpleDateFormat.format(date));
    }

}
