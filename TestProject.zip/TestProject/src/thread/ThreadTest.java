package thread;

public class ThreadTest {

    public static void main(String[] args) {
        //测试线程基础
        testThreadBase();
    }

    public static void testThreadBase(){
        try {
            Thread thread = new Thread(() -> {
                try {
                    Thread.sleep(2000);
                    System.out.println(Thread.currentThread().getId()+"---"+Thread.currentThread().getName());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            thread.start();
            thread.join(1000);
            System.out.println(Thread.currentThread().getId()+"---"+Thread.currentThread().getName());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
