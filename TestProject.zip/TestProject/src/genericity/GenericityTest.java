package genericity;

public class GenericityTest {

    public static void main(String[] args) {

    }

}
