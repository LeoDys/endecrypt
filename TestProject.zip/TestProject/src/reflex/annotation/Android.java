package reflex.annotation;
@Skill(value = true,technologyTypes = {"JAVA","GIT","Grandle"},englishLevel = 8,position = "AndroidDeveloper")
public class Android {
}
