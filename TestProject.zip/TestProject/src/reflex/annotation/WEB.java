package reflex.annotation;
@Skill()
public class WEB {
}
