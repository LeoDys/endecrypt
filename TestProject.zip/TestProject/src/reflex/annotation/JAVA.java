package reflex.annotation;
@Skill(value = false,technologyTypes = {"JAVA","SVN","Jenkins"},englishLevel = 6,position = "JAVADesign")
public class JAVA {
}
