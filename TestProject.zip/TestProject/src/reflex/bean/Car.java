package reflex.bean;

import reflex.bean.Person;

import java.util.List;

public class Car {

    List<Wheel> wheelList;

    List<String> lightList;

    List<Integer> numberList;

    public List<Integer> getNumberList() {
        return numberList;
    }

    public void setNumberList(List<Integer> numberList) {
        this.numberList = numberList;
    }

    public List<String> getLightList() {
        return lightList;
    }

    public void setLightList(List<String> lightList) {
        this.lightList = lightList;
    }

    public List<Wheel> getWheelList() {
        return wheelList;
    }

    public void setWheelList(List<Wheel> wheelList) {
        this.wheelList = wheelList;
    }

    public static class Wheel{
        private int width;
        private int height;
        private String diameter;

        public int getWidth() {
            return width;
        }

        public void setWidth(int width) {
            this.width = width;
        }

        public int getHeight() {
            return height;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public String getDiameter() {
            return diameter;
        }

        public void setDiameter(String diameter) {
            this.diameter = diameter;
        }
    }
}
