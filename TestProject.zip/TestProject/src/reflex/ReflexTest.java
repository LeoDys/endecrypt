package reflex;

import reflex.annotation.Android;
import reflex.annotation.WEB;
import reflex.bean.Car;
import reflex.bean.Worker;
import reflex.bean.Person;
import reflex.constructor.GoodStudent;
import reflex.method.ComputerManager;
import reflex.method.PadManager;
import reflex.proxy.AndroidDeveloper;
import reflex.proxy.Developer;
import reflex.utils.ReflexUtils;

import java.lang.reflect.*;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ReflexTest {

    public static void main(String[] args) {
        //测试反射基础信息
//            testBase();
        //测试反射字段
//        testField();
        //测试反射方法
//        testMethod();
        //测试构造方法
//        testConstructor();
        //测试继承与接口
//        testExtendsAndInterface();
        //测试动态代理
//        testProxy();
        //测试注解
//        testAnnotation();
//        test();
        Car car = new Car();
        List<Car.Wheel> wheelList = new ArrayList<>();
        Car.Wheel w1 = new Car.Wheel();
        w1.setWidth(225);
        w1.setHeight(55);
        w1.setDiameter("R19");
        wheelList.add(w1);

        Car.Wheel w2 = new Car.Wheel();
        w2.setWidth(255);
        w2.setHeight(65);
        w2.setDiameter("R21");
        wheelList.add(w2);
        car.setWheelList(wheelList);

        List<String> lightList = new ArrayList<>();
        lightList.add("车头灯");
        lightList.add("示宽灯");
        lightList.add("雾灯");
        lightList.add("刹车灯");
        car.setLightList(lightList);

        List<Integer> numberList = new ArrayList<>();
        numberList.add(1111);
        numberList.add(2222);
        numberList.add(3333);
        car.setNumberList(numberList);
        getList(car, null);
    }

//    public static Field[] getAllFields(Class c) {
//        List<Field> fieldList = new ArrayList<>();
//        while (c != null) {
//            fieldList.addAll(new ArrayList<>(Arrays.asList(c.getDeclaredFields())));
//            c = c.getSuperclass();
//        }
//        Field[] fields = new Field[fieldList.size()];
//        fieldList.toArray(fields);
//        return fields;
//    }

    public static Field[] filterField(Field[] fields) {

        List<Field> tempList =Arrays.stream(fields).filter(new Predicate<Field>() {
            @Override
            public boolean test(Field field) {
                int modifiers = field.getModifiers();
                if (field!=null&&!Modifier.isFinal(modifiers)&&!Modifier.isStatic(modifiers)&&!Modifier.isAbstract(modifiers)){
                    return true;
                }else{
                    return false;
                }
            }
        }).collect(Collectors.toList());




//        List<Field> tempList = Arrays.stream(fields).filter(field ->null != field
//                && !Modifier.isFinal(field.getModifiers())
//                && !Modifier.isStatic(field.getModifiers())
//                && !Modifier.isAbstract(field.getModifiers())
//        ).collect(Collectors.toList());


//        int arrLength = CollectionUtils.isEmpty(tempList) ? 1:tempList.size();
        int arrLength = (tempList == null || tempList.isEmpty()) ? 1 : tempList.size();

        Field[] resultArr = new Field[arrLength];
        if (tempList != null && !tempList.isEmpty()) {
            tempList.toArray(resultArr);
        }
//        if(!CollectionUtils.isEmpty(tempList)){
//            tempList.toArray(resultArr);
//        }
        return resultArr;
    }


    public static <T> void getList(Object object, T dateClass) {
        List<T> resultList = new ArrayList<>();
//        if(!ObjectUtils.isEmpty(object)){

        Field[] fields = ReflexUtils.getAllFields(object.getClass());
        Field[] filterList = filterField(fields);
        Arrays.stream(filterList).forEach(var -> {
            //List集合
            if (List.class.isAssignableFrom(var.getType())) {
                Type type = var.getGenericType();
                if (type instanceof ParameterizedType) {
                    if (!var.isAccessible()) {
                        var.setAccessible(true);
                    }
                    //获取到属性值的字节码
                    try {
                        Class<?> clzz = var.get(object).getClass();
                        //反射调用获取到list的size方法来获取到集合的大小
                        Method sizeMethod = clzz.getDeclaredMethod("size");
                        if (!sizeMethod.isAccessible()) {
                            sizeMethod.setAccessible(true);
                        }
                        //集合长度
                        int size = (int) sizeMethod.invoke(var.get(object));
                        //循环遍历获取到数据
                        for (int i = 0; i < size; i++) {
                            //反射获取到list的get方法
                            Method getMethod = clzz.getDeclaredMethod("get", int.class);
                            //调用get方法获取数据
                            if (!getMethod.isAccessible()) {
                                getMethod.setAccessible(true);
                            }
                            T var1 = (T) getMethod.invoke(var.get(object), i);
                            resultList.add(var1);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        resultList.stream().forEach(var -> {
            System.out.println("反射获取到的数据是什么:" + var);
        });
//        }
    }

//    private static void test() {
//        try {
//            Car car = new Car();
//            List<String> reports = new ArrayList<>();
//            reports.add("111");
//            reports.add("222");
//            reports.add("333");
//            car.setReports(reports);
//            Field field = car.getClass().getDeclaredField("reports");
//            System.out.println("111："+field.getGenericType());
//            //获取 list 字段的泛型参数
//            ParameterizedType listGenericType = (ParameterizedType) field.getGenericType();
//            System.out.println("222:"+listGenericType.getTypeName());
//            Type[] listActualTypeArguments = listGenericType.getActualTypeArguments();
//            System.out.println("333:"+listActualTypeArguments.length);
//            System.out.println(listActualTypeArguments[listActualTypeArguments.length - 1]);
//            for (int i = 0; i < listActualTypeArguments.length; i++) {
//                System.out.println(listActualTypeArguments[i]);
//            }
//        } catch (NoSuchFieldException e) {
//            e.printStackTrace();
//        }
//    }

    private static void testAnnotation() {
        try {
            ReflexUtils.printAnnotationInfo(Class.forName("reflex.annotation.JAVA"));
            ReflexUtils.printAnnotationInfo(new Android().getClass());
            ReflexUtils.printAnnotationInfo(WEB.class);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void testProxy() {
        //通过动态代理的形式，在代码执行时对调用的方法进行修改
        AndroidDeveloper zhangsan = new AndroidDeveloper("张三");
        Developer zhangsanProxy = (Developer) Proxy.newProxyInstance(zhangsan.getClass().getClassLoader(), zhangsan.getClass().getInterfaces(), new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                if (method.getName().equals("code")) {
                    System.out.println(zhangsan.getName() + "评审原型图和接口文档，需求冻结");
                    return method.invoke(zhangsan, args);
                }
                if (method.getName().equals("debug")) {
                    System.out.println(zhangsan.getName() + "由于编代码前评审原型图和接口文档，调试时问题较少");
                    return null;
                }
                return null;
            }
        });
        zhangsanProxy.code();
        zhangsanProxy.debug();
        System.out.println();
        AndroidDeveloper lisi = new AndroidDeveloper("李四");
        lisi.code();
        lisi.debug();
    }


    private static void testExtendsAndInterface() {
        try {
            ReflexUtils.printExtensAndInterface(Class.forName("reflex.bean.Worker"));
            ReflexUtils.printExtensAndInterface(Integer.class);
            ReflexUtils.printExtensAndInterface(int.class);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void testConstructor() {
        try {
            ReflexUtils.printConstructor(Class.forName("reflex.constructor.Student").getDeclaredConstructor(String.class, int.class).newInstance("张三", 28), "张三", 28, -1);
            ReflexUtils.printConstructor(new GoodStudent(), "李四", 32, 3);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void testMethod() {
        ReflexUtils.printMethods(new ComputerManager(), 3, -1);
        ReflexUtils.printMethods(new PadManager(), 2, 1);
    }

    private static void testField() {
        Worker developer = new Worker();
        developer.setName("张三");
        developer.setAge(28);
        developer.setHeight(175);
        developer.setMarryFlag(true);
        developer.setLevel(3);
        List<String> addressList = new ArrayList<>();
        addressList.add("沈阳");
        addressList.add("深圳");
        developer.setAddressList(addressList);
        List<String> phoneList = new ArrayList<>();
        phoneList.add("13999999999");
        phoneList.add("13888888888");
        String[] phoneArray = new String[phoneList.size()];
        developer.setPhoneArray(phoneList.toArray(phoneArray));
        ReflexUtils.printFields(developer);
        Person.Student student = new Person.Student();
        student.setName("李四");
        student.setAge(30);
        student.setHeight(185);
        student.setMarryFlag(true);
        student.setCartId("000000000000000000000000000000001");
        ReflexUtils.printFields(student);
        Person person = new Person();
        person.setAge(34);
        person.setName("雷嘉");
        person.setHeight(189.20F);
        person.setMarryFlag(false);
        ReflexUtils.printFields(person);
        ReflexUtils.printFields(new String("leij"));
    }

    private static void testBase() {
        try {
            Class stringClass = String.class;
            ReflexUtils.printBaseInfo(stringClass);
            ReflexUtils.printBaseInfo(int.class);
            ReflexUtils.printBaseInfo(String[].class);
            ReflexUtils.printBaseInfo(Object.class);
            ReflexUtils.printBaseInfo(Month.class);
            ReflexUtils.printBaseInfo(Class.forName("reflex.bean.Person"));
            ReflexUtils.printBaseInfo(Class.forName("reflex.bean.Person$Developer"));
            ReflexUtils.printBaseInfo(new ArrayList<Person>().getClass());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


}
