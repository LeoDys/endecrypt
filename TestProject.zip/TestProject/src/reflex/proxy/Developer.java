package reflex.proxy;

public interface Developer {

    void code();

    void debug();

}
