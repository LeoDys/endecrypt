package io;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class IOTest {

    public static void main(String[] args) {
        //测试File
        testFile();
        //测试InputStream
//        testInputStream();
        //测试OutputStream
//        testOutputStream();
        //测试Reader
//        testReader();
        //测试Writer
//        testWriter();

        //未完成，压缩流等等
    }

    private static void testWriter() {
        try (OutputStream outputStream = new FileOutputStream(new File(IOTest.class.getResource(".").getPath() + "\\file\\writerInfo.txt"), true);
             Writer writer = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8)) {
            writer.write("南京英诺森软件科技有限公司\n");
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testReader() {
        try (InputStream inputStream = new FileInputStream(new File(IOTest.class.getResource(".").getPath() + "\\file\\readerInfo.txt"));
             Reader reader = new InputStreamReader(inputStream, StandardCharsets.UTF_8)) {
            char[] buffer = new char[1024];
            int length;
            while ((length = reader.read(buffer)) != -1) {
                System.out.println("readerInfo结果:" + new String(buffer, 0, length));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testOutputStream() {
        try (OutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            byteArrayOutputStream.write("Hello World".getBytes());
//            System.out.println("result:"+new String(byteArrayOutputStream.toByteArray()));
            System.out.println("ByteArrayOutputStream结果:" + new String(byteArrayOutputStream.toString()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (FileOutputStream fileOutputStream = new FileOutputStream(new File(IOTest.class.getResource(".").getPath() + "\\file\\outputStreamInfo.txt"), true)) {
            fileOutputStream.write("南京英诺森软件科技有限公司\n".getBytes());
            fileOutputStream.flush();
            System.out.println("数据写入成功");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testInputStream() {
        byte[] data = {72, 101, 108, 108, 111, 33};
        try (InputStream byteArrayInputStream = new ByteArrayInputStream(data)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = byteArrayInputStream.read(buffer)) != -1) {
                System.out.println("ByteArrayInputStream结果:" + new String(buffer, 0, length));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (FileInputStream fileInputStream = new FileInputStream(new File(IOTest.class.getResource(".").getPath() + "\\file\\inputStreamInfo.txt"))) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fileInputStream.read(buffer)) != -1) {
                System.out.println("inputStreamInfo.txt结果:" + new String(buffer, 0, length));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testFile() {
        try {
            File file1 = new File("..");//上级目录
            System.out.println("【new File(\"..\")】getPath:【" + file1.getPath() + "】,getAbsolutePath:【" + file1.getAbsolutePath() + "】,getCanonicalPath:【" + file1.getCanonicalPath() + "】");
            File file2 = new File("C:\\Windows");
            System.out.println("【C:\\Windows】File:【" + file2.isFile() + "】,Directory:【" + file2.isDirectory() + "】");
            File file3 = new File("C:\\Windows\\notepad.exe");//记事本
            System.out.println("【C:\\Windows\\notepad.exe】File:【" + file3.isFile() + "】,Directory:【" + file3.isDirectory() + "】");
            File file4 = new File("C:\\Windows\\nothing");//不存在的目录
            System.out.println("【C:\\Windows\\nothing】File:【" + file4.isFile() + "】,Directory:【" + file4.isDirectory() + "】");
            File file5 = new File("C:\\Windows\\System32\\calc.exe");//计算器
            System.out.println("【C:\\Windows\\System32\\calc.exe】canRead:【" + file5.canRead() + "】,canWrite:【" + file5.canWrite() + "】,canExcute:【" + file5.canExecute() + "】,length:【" + file5.length() + "】");

            File createFile = new File("D:\\Temp.txt");
            if (!createFile.exists()) {
                System.out.println("创建D:\\Temp.txt结果：" + createFile.createNewFile());
            }

            File desktopFile = new File("C:\\Users\\Administrator\\Desktop");
            String[] fileNameArray = desktopFile.list();//获取文件名称
            for (String fileName : fileNameArray) {
                System.out.println("文件名称：" + fileName);
            }
            //FileFilter可以对获取的文件数组进行过滤
            File[] fileList = desktopFile.listFiles(file -> {
                if (file.getName().endsWith(".doc")) {
                    return true;
                } else {
                    return false;
                }
            });
            for (File file : fileList) {
                System.out.println("文件名称：" + file.getName() + ",文件路径：" + file.getAbsolutePath());
            }

            File makeFile = new File("D:\\test\\test\\test\\");
            System.out.println("使用mkdir(),创建D:\\test\\test\\test\\结果：" + makeFile.mkdir());//如果中间路径不存在时使用mkdir创建失败，只能创建目录，创建文件使用createNewFile。
            System.out.println("使用mkdirs(),创建D:\\test\\test\\test\\结果：" + makeFile.mkdirs());//如果中间路径不存在时使用mkdirs会创建中间路径，只能创建目录，创建文件使用createNewFile。
            System.out.println("使用delete(),删除D:\\test\\test\\test\\结果：" + makeFile.delete());//file包含子文件时删除失败

            System.out.println("路径1："+IOTest.class.getResource("").getPath());
            System.out.println("路径2："+IOTest.class.getResource("/").getPath());
            System.out.println("路径3："+Thread.currentThread().getContextClassLoader().getResource("").getPath());
            System.out.println("路径4："+IOTest.class.getClassLoader().getResource("").getPath());
            System.out.println("路径5："+ClassLoader.getSystemResource("").getPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
