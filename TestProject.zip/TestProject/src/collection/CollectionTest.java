package collection;

import collection.bean.Person;
import collection.bean.User;
import collection.enumPackage.Week;

import java.io.*;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class CollectionTest {

    public static void main(String[] args) {
        //测试基本方法
//        testBase();
        //测试ArrayList和LinkedList的效率
//        testArrayListAndLinkedList();
        //测试HashMap
//        testHashMap();
//测试EnumMap
//        testEnumMap();
        //测试TreeMap
//        testTreeMap();
        //测试Properties
//        testProperties();
        //测试Set
//        testSet();
        //测试Queue
//        testQueue();
        //测试PriorityQueue
        testPriorityQueue();
    }

    private static void testPriorityQueue(){
        //传入Comparator对象实现compare方法来编写优先级的代码
        PriorityQueue<User> priorityQueue = new PriorityQueue<>(new Comparator<User>() {
            @Override
            public int compare(User user1, User user2) {
                String type1 = user1.getNumber().substring(0,1);
                int number1 = Integer.parseInt(user1.getNumber().substring(1));
                String type2 =user2.getNumber().substring(0,1);
                int number2 = Integer.parseInt(user2.getNumber().substring(1));
                if(type1.equals(type2)){
                    if(number1>number2){
                        return 1;
                    }else if(number1<number2){
                        return -1;
                    }else{
                        return 0;
                    }
                }else{
                    if("V".equals(type1)){
                        return -1;
                    }else if("V".equals(type2)){
                        return 1;
                    }else{
                        return 0;
                    }
                }
            }
        });
        priorityQueue.offer(new User("张三","A1"));
        priorityQueue.offer(new User("李四","A2"));
        priorityQueue.offer(new User("王五","V1"));
        User user = priorityQueue.poll();
        System.out.println("name:"+user.getName()+",number:"+user.getNumber());
        user = priorityQueue.poll();
        System.out.println("name:"+user.getName()+",number:"+user.getNumber());
        user = priorityQueue.poll();
        System.out.println("name:"+user.getName()+",number:"+user.getNumber());
        if(priorityQueue.isEmpty()){
            System.out.println("priorityQueue已经为空");
        }
    }

    private static void testQueue(){
        Queue<String> queue = new LinkedList<>();
        queue.add("张三");//队列已满时报错
        queue.offer("李四");//队列已满时返回false
        System.out.println("队列长度:"+queue.size());
        String element = queue.element();//查出数据但不移除，队列为空报错
        String peek = queue.peek();//查出数据但不移除，队列为空返回false
        System.out.println("element:"+element+",peek:"+peek);
        System.out.println("队列长度:"+queue.size());
        String remove = queue.remove();//查出数据并移除，队列为空报错
        String poll = queue.poll();//查出数据并移除，队列为空返回false
        System.out.println("remove:"+remove+",poll:"+poll);
        System.out.println("队列长度:"+queue.size());
        String removeException = queue.remove();//查出数据并移除，队列为空报错
        System.out.println("队列长度:"+queue.size());
    }

    private static void testSet() {
        HashSet<String> hashSet =new HashSet<>(Set.of("apple", "banana", "pear", "orange")) ;
        for (String message : hashSet) {
            System.out.print(message + "-");
        }
        System.out.println();
        TreeSet<String> treeSet = new TreeSet<>(Set.of("apple", "banana", "pear", "orange"));
        for (String message : treeSet) {
            System.out.print(message + "-");
        }
        System.out.println();
    }

    private static void testProperties() {
        try {
            //请将Idea的工程字符集改成UTF-8，properties文件的字符集编码改为UTF-8
            Properties properties = new Properties();
            properties.load(new FileReader("C:/IdeaProject/TestProject/src/collection/properties/testProperties.properties"));
            String name = properties.getProperty("name");
            int age = Integer.parseInt(properties.getProperty("age"));
            String address = properties.getProperty("address");
            System.out.println("name【" + name + "】,age【" + age + "】,address【" + address + "】");
            properties.setProperty("address", "辽宁");
            properties.store(new FileOutputStream("C:/IdeaProject/TestProject/src/collection/properties/testProperties.properties"), "这是写入的properties注释");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testTreeMap() {
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("c", 333);
        treeMap.put("a", 111);
        treeMap.put("b", 222);
        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
            System.out.println("英文【" + entry.getKey() + "】,数字【" + entry.getValue() + "】");
        }
    }

    private static void testEnumMap() {
        Map<Week, String> enumMap = new EnumMap<>(Week.class);
        enumMap.put(Week.MONDAY, "星期一");
        enumMap.put(Week.TUESDAY, "星期二");
        enumMap.put(Week.WEDNESDAY, "星期三");
        enumMap.put(Week.THURSDAY, "星期四");
        enumMap.put(Week.FRIDAY, "星期五");
        enumMap.put(Week.SATURDAY, "星期六");
        enumMap.put(Week.SUNDAY, "星期日");
        for (Map.Entry<Week, String> entry : enumMap.entrySet()) {
            System.out.println("英文【" + entry.getKey() + "】,中文【" + entry.getValue() + "】");
        }
    }

    private static void testBase() {
        //初始化List
        List<String> list = List.of("刘一", "陈二", "张三", "李四", "王五", "赵六", "孙七", "周八", "吴九", "郑十");
        list.forEach(System.out::print);
        System.out.println();

        //List转数组
//        String[] array = list.toArray(new String[list.size()]);
        String[] array = list.toArray(String[]::new);
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
        }
        System.out.println();

        //数组转List加数据，遍历
        ArrayList<String> list1 = new ArrayList(List.of(array));
        list1.add("aaa");
        list1.forEach(str -> {
            System.out.print(str);
        });
        System.out.println();

    }

    private static void testHashMap() {
        //初始化Map，遍历Map
        Map<String, Person> map = Map.of("张三", new Person("张三", 18), "李四", new Person("李四", 28), "王五", new Person("王五", 38));
        for (Map.Entry<String, Person> entry : map.entrySet()) {
            System.out.println("姓名【" + entry.getKey() + "】,年龄【" + entry.getValue().getAge() + "】");
        }
    }

    private static void testArrayListAndLinkedList() {
        List<String> arrayList = new ArrayList<>();
        List<String> linkedList = new LinkedList<>();
        //ArrayList插入
        long begin1 = System.currentTimeMillis();
        for (int i = 0; i < 50000; i++) {
            arrayList.add(0, UUID.randomUUID().toString());
        }
        long end1 = System.currentTimeMillis();
        System.out.println("ArrayList插入用时：" + String.valueOf(end1 - begin1) + "毫秒，集合Size：" + arrayList.size());

        //ArrayList普通遍历
        long begin2 = System.currentTimeMillis();
        for (int i = 0; i < arrayList.size(); i++) {
            arrayList.get(i);
        }
        long end2 = System.currentTimeMillis();
        System.out.println("ArrayList遍历用时：" + String.valueOf(end2 - begin2) + "毫秒");

        //ArrayList迭代器遍历
        long begin3 = System.currentTimeMillis();
        for (Iterator<String> it = arrayList.iterator(); it.hasNext(); ) {
            it.next();
        }
        long end3 = System.currentTimeMillis();
        System.out.println("ArrayList迭代器遍历用时：" + String.valueOf(end3 - begin3) + "毫秒");

        //LinkedList插入
        long begin4 = System.currentTimeMillis();
        for (int i = 0; i < 50000; i++) {
            linkedList.add(0, UUID.randomUUID().toString());
        }
        long end4 = System.currentTimeMillis();
        System.out.println("LinkedList插入用时：" + String.valueOf(end4 - begin4) + "毫秒，集合Size：" + linkedList.size());

        //LinkedList普通遍历
        long begin5 = System.currentTimeMillis();
        for (int i = 0; i < linkedList.size(); i++) {
            linkedList.get(i);
        }
        long end5 = System.currentTimeMillis();
        System.out.println("LinkedList遍历用时：" + String.valueOf(end5 - begin5) + "毫秒");

        //LinkedList迭代器遍历
        long begin6 = System.currentTimeMillis();
//        for (Iterator<String> it = linkedList.iterator(); it.hasNext();) {
//            it.next();
//        }
        for (String uuid : linkedList) {

        }
        long end6 = System.currentTimeMillis();
        System.out.println("LinkedList迭代器遍历用时：" + String.valueOf(end6 - begin6) + "毫秒");
    }

}
