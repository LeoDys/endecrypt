package security.encode;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;

public class EncodeUtils {

    public static String urlEncode(String urlPlaintext,Charset charSet ){
//        return URLEncoder.encode(urlPlaintext, charSet==null?StandardCharsets.UTF_8:charSet);
        return URLEncoder.encode(urlPlaintext, charSet==null?Charset.defaultCharset():charSet);
    }

    public static String urlDecode(String urlCiphertext,Charset charset){
//        return URLDecoder.decode(urlCiphertext,charset==null?StandardCharsets.UTF_8:charset);
        return URLDecoder.decode(urlCiphertext,charset==null?Charset.defaultCharset():charset);
    }

    public static String base64Endoce(String base64Plaintext,Charset charSet){
//        byte[] bytes = base64Plaintext.getBytes(charSet==null?StandardCharsets.UTF_8:charSet);
        byte[] bytes = base64Plaintext.getBytes(charSet==null?Charset.defaultCharset():charSet);
        return Base64.getEncoder().encodeToString(bytes);
    }

    public static String base64Decode(String base64Ciphertext,Charset charset){
//        byte[] bytes = base64Ciphertext.getBytes(charset==null?StandardCharsets.UTF_8:charset);
        byte[] bytes = base64Ciphertext.getBytes(charset==null?Charset.defaultCharset():charset);
        return new String(Base64.getDecoder().decode(bytes));
    }

    public static String base64URLEncode(String base64URLPaintext,Charset charSet){
//        byte[] bytes = base64URLPaintext.getBytes(charSet==null?StandardCharsets.UTF_8:charSet);
        byte[] bytes = base64URLPaintext.getBytes(charSet==null?Charset.defaultCharset():charSet);
        return Base64.getUrlEncoder().encodeToString(bytes);
    }

    public static String base64URLDecode(String base64URLCiphertext,Charset charset){
//        byte[] bytes = base64URLCiphertext.getBytes(charset==null?StandardCharsets.UTF_8:charset);
        byte[] bytes = base64URLCiphertext.getBytes(charset==null?Charset.defaultCharset():charset);
        return new String((Base64.getUrlDecoder().decode(bytes)));
    }
}
