package security;

import com.sun.tools.javac.Main;
import security.asymmetricEncryption.AsymmetricEncryptionUtils;
import security.certificate.CertificateUtils;
import security.encode.EncodeUtils;
import security.hash.HashUtils;
import security.symmetricEncryption.SymmetricEncryptionUtils;

import javax.crypto.SecretKey;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.URL;
import java.nio.file.NoSuchFileException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;
import java.util.Map;

public class SecurityTest {

    public static void main(String[] args) {
        //测试URL编码，Base64编码，Base64URL编码
//        testEncodeAndDecode();
        //测试Hash
//        testHash();
        //测试HMAC
//        testHMACHash();
        //测试对称加密
//        testSymmetricEncryption();
        //测试非对称加密
//        testAsymmetricEncryption();
        //测试签名
//        testSign();
        //测试数字证书
        testCertificate();
    }

    //证书密码【123456】，别名【test】
    public static void testCertificate() {
        String plaintext = "HelloWorld";
        // 读取KeyStore
//            KeyStore keyStore = CertificateUtils.loadKeyStore(new FileInputStream(new File(SecurityTest.class.getResource("certificate/test.keystore").getPath())),"123456");
//            KeyStore keyStore = CertificateUtils.loadKeyStore(SecurityTest.class.getResource("certificate/test.keystore").getPath(),"123456");
        KeyStore keyStore = CertificateUtils.loadKeyStore(SecurityTest.class.getResourceAsStream("certificate/test.keystore"), "123456");
        // 读取私钥:
        PrivateKey privateKey = CertificateUtils.getPriveteKey(keyStore, "test", "123456");
        // 读取证书:
        X509Certificate certificate = CertificateUtils.getCertificate(keyStore, "test");
        System.out.println("公钥："+Base64.getEncoder().encodeToString(certificate.getPublicKey().getEncoded()));
        System.out.println("密钥："+Base64.getEncoder().encodeToString(privateKey.getEncoded()));
        // 加密:
        String ciphertext = CertificateUtils.encrypt(certificate, plaintext, null);
        System.out.println("加密后：" + ciphertext);
        // 解密:
        String result = CertificateUtils.decrypt(privateKey, ciphertext, null);
        System.out.println("解密后：" + result);
        // 签名:
        String sign = CertificateUtils.sign(privateKey, certificate, plaintext,null);
        System.out.println("签名：" + sign);
        // 验证签名:
        boolean verify = CertificateUtils.verify(certificate, plaintext, sign,null);
        System.out.println("验证结果：" + verify);
    }

    public static void testSign() {
        long beginRSA = System.currentTimeMillis();
        Map<String, byte[]> keyPairRSA = AsymmetricEncryptionUtils.generateKeyPair(AsymmetricEncryptionUtils.ALGORITHM_RSA, null);
        byte[] publicKeyRSA = AsymmetricEncryptionUtils.getPublicKey(keyPairRSA);
        byte[] privateKeyRSA = AsymmetricEncryptionUtils.getPrivateKey(keyPairRSA);
        String ciphertextRSA = AsymmetricEncryptionUtils.signRSA(privateKeyRSA, "HelloWorld", null);
        boolean resultRSA = AsymmetricEncryptionUtils.verifyRSA(publicKeyRSA, "HelloWorld", ciphertextRSA, null);
        System.out.println("RSA签名校验结果：" + resultRSA);
        long endRSA = System.currentTimeMillis();
        System.out.println("RSA签名校验耗时：" + (endRSA - beginRSA));

        long beginDSA = System.currentTimeMillis();
        Map<String, byte[]> keyPairDSA = AsymmetricEncryptionUtils.generateKeyPair(AsymmetricEncryptionUtils.ALGORITHM_DSA, null);
        byte[] publicKeyDSA = AsymmetricEncryptionUtils.getPublicKey(keyPairDSA);
        byte[] privateKeyDSA = AsymmetricEncryptionUtils.getPrivateKey(keyPairDSA);
        String ciphertextDSA = AsymmetricEncryptionUtils.signDSA(privateKeyDSA, "HelloWorld", null);
        boolean resultDSA = AsymmetricEncryptionUtils.verifyDSA(publicKeyDSA, "HelloWorld", ciphertextDSA, null);
        System.out.println("DSA签名校验结果：" + resultDSA);
        long endDSA = System.currentTimeMillis();
        System.out.println("DSA签名校验耗时：" + (endDSA - beginDSA));

    }

    public static void testAsymmetricEncryption() {
        Map<String, byte[]> keyPairA = AsymmetricEncryptionUtils.generateKeyPair(AsymmetricEncryptionUtils.ALGORITHM_DH, null);
        Map<String, byte[]> keyPairB = AsymmetricEncryptionUtils.generateKeyPair(AsymmetricEncryptionUtils.ALGORITHM_DH, null);
        byte[] publicKeyA = AsymmetricEncryptionUtils.getPublicKey(keyPairA);
        byte[] privateKeyA = AsymmetricEncryptionUtils.getPrivateKey(keyPairA);
        byte[] publicKeyB = AsymmetricEncryptionUtils.getPublicKey(keyPairB);
        byte[] privateKeyB = AsymmetricEncryptionUtils.getPrivateKey(keyPairB);
        byte[] secretKeyA = AsymmetricEncryptionUtils.generateSecretKey(AsymmetricEncryptionUtils.ALGORITHM_DH, publicKeyB, privateKeyA);
        byte[] secretKeyB = AsymmetricEncryptionUtils.generateSecretKey(AsymmetricEncryptionUtils.ALGORITHM_DH, publicKeyA, privateKeyB);
        System.out.println("A公钥：" + Base64.getEncoder().encodeToString(publicKeyA));
        System.out.println("A私钥：" + Base64.getEncoder().encodeToString(privateKeyA));
        System.out.println("A密钥：" + Base64.getEncoder().encodeToString(secretKeyA));
        System.out.println("B公钥：" + Base64.getEncoder().encodeToString(publicKeyB));
        System.out.println("B私钥：" + Base64.getEncoder().encodeToString(privateKeyB));
        System.out.println("B密钥：" + Base64.getEncoder().encodeToString(secretKeyB));

        Map<String, byte[]> keyPairC = AsymmetricEncryptionUtils.generateKeyPair(AsymmetricEncryptionUtils.ALGORITHM_RSA, null);
        Map<String, byte[]> keyPairD = AsymmetricEncryptionUtils.generateKeyPair(AsymmetricEncryptionUtils.ALGORITHM_RSA, null);
        byte[] publicKeyC = AsymmetricEncryptionUtils.getPublicKey(keyPairC);
        byte[] privateKeyC = AsymmetricEncryptionUtils.getPrivateKey(keyPairC);
        byte[] publicKeyD = AsymmetricEncryptionUtils.getPublicKey(keyPairD);
        byte[] privateKeyD = AsymmetricEncryptionUtils.getPrivateKey(keyPairD);
        String ciphertextC = AsymmetricEncryptionUtils.encryptRSA(publicKeyC, "MOBILE_DEVELOPER", null);
        String plaintextC = AsymmetricEncryptionUtils.decryptRSA(privateKeyC, ciphertextC, null);
        System.out.println("C公钥加密：" + ciphertextC);
        System.out.println("C私钥解密：" + plaintextC);
        String ciphertextD = AsymmetricEncryptionUtils.encryptRSA(publicKeyD, "MOBILE_DEVELOPER", null);
        String plaintextD = AsymmetricEncryptionUtils.decryptRSA(privateKeyD, ciphertextD, null);
        System.out.println("D公钥加密：" + ciphertextD);
        System.out.println("D私钥解密：" + plaintextD);

    }

    public static void test() {
        byte[] a = new byte[]{17, 18, 19, 20};
        byte[] b = new byte[]{27, 28, 29, 30};
        System.out.println(Arrays.toString(a));
        System.out.println(Arrays.toString(b));
        byte[] c = new byte[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        System.out.println(Arrays.toString(c));
    }

    public static void testSymmetricEncryption() {
        //默认AES加密
        String ciphertext = SymmetricEncryptionUtils.encryptAES(SymmetricEncryptionUtils.DEFAULT_AES_SECRET_KEY, "HellowWorld", null);
        System.out.println(ciphertext);
        String plaintext = SymmetricEncryptionUtils.decryptAES(SymmetricEncryptionUtils.DEFAULT_AES_SECRET_KEY, ciphertext, null);
        System.out.println(plaintext);

        //AES加密，CBC，每次随机IV，(建议使用)
        String ciphertext1 = SymmetricEncryptionUtils.encryptAESRandomIV(SymmetricEncryptionUtils.DEFAULT_AES_SECRET_KEY, "HellowWorld", null);
        System.out.println(ciphertext1);
        String plaintext1 = SymmetricEncryptionUtils.decryptAESRandomIV(SymmetricEncryptionUtils.DEFAULT_AES_SECRET_KEY, ciphertext1, null);
        System.out.println(plaintext1);

        //AES加密，CBC，自定义IV
        String ciphertext2 = SymmetricEncryptionUtils.encryptAESWithIV(SymmetricEncryptionUtils.DEFAULT_AES_SECRET_KEY, "HellowWorld", SymmetricEncryptionUtils.DEFAULT_AES_INITIALIZATION_VECTOR, null);
        System.out.println(ciphertext2);
        String plaintext2 = SymmetricEncryptionUtils.decryptAESWithIV(SymmetricEncryptionUtils.DEFAULT_AES_SECRET_KEY, ciphertext2, SymmetricEncryptionUtils.DEFAULT_AES_INITIALIZATION_VECTOR, null);
        System.out.println(plaintext2);


    }

    public static void testHMACHash() {
        String secretKeyStr = HashUtils.createHmacSecretKey(HashUtils.HMAC_ALGORITHM_MD5);
        String secretKeyStr2 = HashUtils.createHmacSecretKey(HashUtils.HMAC_ALGORITHM_SHA1);
        System.out.println(secretKeyStr);
        System.out.println(secretKeyStr2);
        SecretKey secretKey = HashUtils.getHmacSecretKey(HashUtils.HMAC_ALGORITHM_MD5, secretKeyStr);
        System.out.println(new BigInteger(1, secretKey.getEncoded()).toString(16));
        System.out.println(HashUtils.hmacHashMD5(secretKey, "HelloWorld", null));
        System.out.println(HashUtils.hmacHashSHA1(secretKey, "HelloWorld", null));
        System.out.println(HashUtils.hmacHashSHA256(secretKey, "HelloWorld", null));
        System.out.println(HashUtils.hmacHashSHA512(secretKey, "HelloWorld", null));
        System.out.println(HashUtils.hmacHashWithAlgorithm(HashUtils.HMAC_ALGORITHM_SHA224, secretKey, "HelloWorld", null));
        System.out.println(HashUtils.hmacHashWithAlgorithm(HashUtils.HMAC_ALGORITHM_SHA384, secretKey, "HelloWorld", null));
    }

    public static void testHash() {
        System.out.println(HashUtils.hashMD5("HelloWorld", null));
        System.out.println(HashUtils.hashSHA1("HelloWorld", null));
        System.out.println(HashUtils.hashSHA256("HelloWorld", null));
        System.out.println(HashUtils.hashSHA512("HelloWorld", null));
//        System.out.println(HashUtils.hashWithAlgorithm(HashUtils.ALGORITHM_MD2,"HelloWorld",null));
        System.out.println(HashUtils.hashWithAlgorithm(HashUtils.ALGORITHM_SHA224, "HelloWorld", null));
        System.out.println(HashUtils.hashWithAlgorithm(HashUtils.ALGORITHM_SHA384, "HelloWorld", null));
//        System.out.println(HashUtils.hashWithAlgorithm(HashUtils.ALGORITHM_SHA512_224,"HelloWorld",null));
//        System.out.println(HashUtils.hashWithAlgorithm(HashUtils.ALGORITHM_SHA512_256,"HelloWorld",null));
    }

    public static void testEncodeAndDecode() {

        String urlPlaintext = "https://www.baidu.com/s?wd=沈阳";
        String urlCipherText = EncodeUtils.urlEncode(urlPlaintext, null);
        System.out.println(urlCipherText);
        System.out.println(EncodeUtils.urlDecode(urlCipherText, null));

        String base64Plaintext = "在java中，一切存储在硬盘上的数据都是二进制的字节";
        String base64Ciphertext = EncodeUtils.base64Endoce(base64Plaintext, null);
        System.out.println(base64Ciphertext);
        System.out.println(EncodeUtils.base64Decode(base64Ciphertext, null));

        String base64URLPlaintext = "https://www.baidu.com/s?wd=大连";
        String base64URLCipherText = EncodeUtils.base64URLEncode(base64URLPlaintext, null);
        System.out.println(base64URLCipherText);
        System.out.println(EncodeUtils.base64URLDecode(base64URLCipherText, null));

    }

}
