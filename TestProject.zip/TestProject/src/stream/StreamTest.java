package stream;

public class StreamTest {
    public static void main(String[] args) {

    }
}
