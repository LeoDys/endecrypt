package lambda.interfacePackage;
@FunctionalInterface
public interface NoReturnMultipleParam {
    void method(String name,int age);
}