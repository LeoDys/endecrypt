package lambda.interfacePackage;

@FunctionalInterface
public interface ReturnNoParam {
    String method();
}
