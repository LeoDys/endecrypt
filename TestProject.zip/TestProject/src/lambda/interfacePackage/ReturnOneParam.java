package lambda.interfacePackage;

@FunctionalInterface
public interface ReturnOneParam {
    String method(String name);
}
