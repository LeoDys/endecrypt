package lambda.interfacePackage;

@FunctionalInterface
public interface NoReturnNoParam {

    void method();

}
