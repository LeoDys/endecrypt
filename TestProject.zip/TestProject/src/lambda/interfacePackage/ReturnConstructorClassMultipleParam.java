package lambda.interfacePackage;

import lambda.classPackage.ConstructorClass;

@FunctionalInterface
public interface ReturnConstructorClassMultipleParam {

    ConstructorClass method(String name, int age);

}
