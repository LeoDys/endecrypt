package lambda.interfacePackage;

@FunctionalInterface
public interface NoReturnOneParam {
    void method(String name);
}
