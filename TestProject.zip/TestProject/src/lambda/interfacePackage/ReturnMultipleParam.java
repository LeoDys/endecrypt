package lambda.interfacePackage;

@FunctionalInterface
public interface ReturnMultipleParam {
    String method(String name,int age);
}
