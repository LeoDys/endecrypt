package lambda.classPackage;

public class ConstructorClass {

    public ConstructorClass() {
        System.out.println("ConstructorClass");
    }

    public ConstructorClass(String name,int age){
        System.out.println("ConstructorClass:name【"+name+"】,age【"+age+"】");
    }

    public void success(){
        System.out.println("ConstructorClass构造方法执行success");
    }
}
