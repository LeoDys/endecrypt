package lambda.utils;

import lambda.classPackage.Employee;

public class LambdaUtils {

    public static void print(Employee employee){
        System.out.println("name【"+employee.getName()+"】,age【"+employee.getAge()+"】");
    }

}
