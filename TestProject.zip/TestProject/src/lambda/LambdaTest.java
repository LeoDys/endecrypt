package lambda;

import lambda.classPackage.ConstructorClass;
import lambda.classPackage.Employee;
import lambda.interfacePackage.*;
import lambda.utils.LambdaUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LambdaTest {

    public static void main(String[] args) {
        //测试Lambda基本语法
        testLambdaBase();
        //测试Lambda直接调用方法，方法的参数和返回值必须与接口一致
        testLambdaMethod();
        //测试Lambda直接调用构造方法
        testLambdaConstructor();
        //测试Lambda启动线程例子
        testLambdaThreadExample();
        //测试Lambda便利集合例子
        testLambdaCollectionExample();
        //测试Lambda集合排序例子
        testLambdaCollectionSortExample();
    }

    private static void testLambdaCollectionSortExample(){
        Employee employee1 = new Employee("张三",38);
        Employee employee2 = new Employee("李四",25);
        Employee employee3 = new Employee("王五",43);
        Employee employee4 = new Employee("赵六",22);
        List<Employee> list = new ArrayList<>();
        Collections.addAll(list,employee1,employee2,employee3,employee4);
        //便利方式一：常用方法
        for (Employee employee:list) {
            System.out.println("name【"+employee.getName()+"】,age【"+employee.getAge()+"】");
        }

//        Collections.sort(list,(emp1,emp2)->{
//            return emp1.getAge()-emp2.getAge();
//        });
        Collections.sort(list, Comparator.comparingInt(Employee::getAge));

        System.out.println("按年龄升序排序");

        //便利方式二：lambda直接调用方法
        list.forEach(LambdaUtils::print);
    }

    private static void testLambdaCollectionExample(){
        List<String> list = new ArrayList<>();
        Collections.addAll(list,"张三","李四","王五","赵六");
        //便利方式一：常用方法
        list.forEach(str->{
            System.out.println(str);
        });

        //删除两个人，一个存在，一个不存在
        String removeName1 ="王五";
        String removeName2 ="孙七";
        System.out.println("删除"+removeName1+"结果："+list.removeIf(str -> removeName1.equals(str)));
        System.out.println("删除"+removeName2+"结果："+list.removeIf(str -> removeName2.equals(str)));

        //便利方式二：lambda直接调用方法
        list.forEach(System.out::println);
    }


    private static void testLambdaThreadExample() {
        for (int i = 0; i < 10; i++) {
            Thread thread = new Thread(() -> {
                System.out.println("Thread:【id=" + Thread.currentThread().getId() + "】,【" + Thread.currentThread().getName() + "】");
            });
            thread.start();
        }
    }

    private static void testLambdaConstructor() {
        //String无参数构造方法调用
        ReturnNoParam returnNoParam = String::new;
        System.out.println("ReturnNoParam:"+returnNoParam.method());

        //String带参数构造方法调用
        ReturnOneParam returnOneParam = String::new;
        System.out.println("ReturnOneParam:"+returnOneParam.method("张三"));

        //ConstructorClass带参数构造方法调用
        ReturnConstructorClassMultipleParam returnConstructorClassMultipleParam = ConstructorClass::new;
        ConstructorClass constructorClass = returnConstructorClassMultipleParam.method("李四",28);
        constructorClass.success();
    }

    private static void testLambdaMethod() {
        //常用情况
        NoReturnMultipleParam noReturnMultiPleParam = (name, age) -> {
            System.out.println("noReturnMultiPleParam:[name:" + name + "---age:" + age + "]");
            printNameAndAge(name, age);
        };
        noReturnMultiPleParam.method("张三", 30);

        //静态类调用情况
        NoReturnMultipleParam noReturnMultiPleParam2 = LambdaTest::printNameAndAge;
        noReturnMultiPleParam2.method("李四", 28);

        //实例调用情况
        LambdaTest lambdaTestObject = new LambdaTest();
        ReturnMultipleParam ReturnMultipleParam = lambdaTestObject::printNameAndAgeWithoutStatic;//使用对象方式调用时，方法不能是static
        System.out.println(ReturnMultipleParam.method("王五", 50));

    }

    private static void testLambdaBase() {
        NoReturnMultipleParam noReturnMultiPleParam = (name, age) -> {
            System.out.println("noReturnMultiPleParam:[name:" + name + "---age:" + age + "]");
        };
        noReturnMultiPleParam.method("AAA", 34);

        NoReturnOneParam noReturnOneParam = name -> {
            System.out.println("noReturnOneParam:[name:" + name + "]");
        };
        noReturnOneParam.method("BBB");

        NoReturnNoParam noReturnNoParam = () -> {
            System.out.println("noReturnNoParam:");
        };
        noReturnNoParam.method();

        ReturnMultipleParam returnMultipleParam = (name, age) -> "returnMultipleParam:[name:" + name + "---age:" + age + "]";
        System.out.println(returnMultipleParam.method("CCC", 29));

        ReturnOneParam returnOneParam = name -> "returnOneParam:[name:" + name + "]";
        System.out.println(returnOneParam.method("DDD"));

        ReturnNoParam returnNoParam = () -> "returnNoParam:";
        System.out.println(returnNoParam.method());
    }

    private static void printNameAndAge(String name, int age) {
        System.out.println("执行printNameAndAge方法，name【" + name + "】，age【" + age + "】");
    }

    private String printNameAndAgeWithoutStatic(String name, int age) {
        return "执行printNameAndAgeWithoutStatic方法，name【" + name + "】，age【" + age + "】";
    }
}
